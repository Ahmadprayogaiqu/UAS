<div class="row">
    <div class="col-md-12">
        <center>
            <footer>
                <div>
                    <small style="font-family: 'Jetbrains_Mono'; color: white;">Copyright &copy; 2021 Rizal Ihwan</small>
                </div>
                <div>
                    <a href="https://web.facebook.com/izal.whanz/"><img src="{{ asset('logo/fb.svg') }}" width="50" alt="" srcset="" ></a>
                    <a href="https://www.instagram.com/rizalihwan94_/"><img src="{{ asset('logo/ig.svg') }}" width="50" alt="" srcset=""></a>
                    <a href="https://wa.me/+6285770254568"><img src="{{ asset('logo/wa.svg') }}" width="50" alt="" srcset=""></a>
                </div>
            </footer>
        </center>
    </div>
</div>
